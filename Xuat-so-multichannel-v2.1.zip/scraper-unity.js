/* Đọc bảng spend theo giờ trên trang Unity Ads (Acquire › Performance, chế độ Table, Hourly).
   Đã kiểm tra trên trang thật: bảng MUI DataGrid ảo hóa (cuộn mới hiện dòng); mỗi dòng có data-id = mốc đầu giờ
   (epoch ms, UTC), cột thời gian data-field="__tree_data_group__" ("Oct 12, 00:00 – 01:00"), cột spend
   data-field="acquisition/spend" ("$1.01", dòng 2 là % so kỳ trước). Trang ghi "Reports are based on UTC".
   Tự chứa hết vì được tiêm vào trang. */
async function scrapeUnityHourly() {
  const clean = s => (s || '').replace(/\s+/g, ' ').trim();
  const first = el => el ? ((el.innerText || '').split('\n').map(x => x.trim()).find(Boolean) || '') : '';
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const grid = document.querySelector('.MuiDataGrid-root');
  const btns = [...document.querySelectorAll('button')].map(b => clean(b.innerText));
  const granularity = btns.find(t => /^(hourly|daily|weekly|monthly)$/i.test(t)) || '';
  const range = btns.find(t => /\b(19|20)\d{2}\b/.test(t) && /[–-]/.test(t)) || '';
  const utc = /based on UTC/i.test(document.body.innerText);
  if (!grid) return { ok: false, error: 'NO_GRID', granularity, range };
  const heads = [...grid.querySelectorAll('.MuiDataGrid-columnHeader')].map(h => ({ field: h.getAttribute('data-field'), text: clean(h.innerText) }));
  const spendH = heads.find(h => /^spend\b/i.test(h.text)) || heads.find(h => /\/spend$/.test(h.field || ''));
  const timeH = heads.find(h => /^time$/i.test(h.text)) || heads[0];
  if (!spendH) return { ok: false, error: 'NO_SPEND', granularity, range, found: heads.map(h => h.text) };
  const sel = f => `[data-field="${CSS.escape(f)}"]`;
  const p2 = x => String(x).padStart(2, '0');
  const wall = ms => { const d = new Date(ms); return `${d.getUTCFullYear()}-${p2(d.getUTCMonth() + 1)}-${p2(d.getUTCDate())} ${p2(d.getUTCHours())}:00`; };
  const got = new Map();
  let overall = '';
  const grab = () => {
    for (const r of grid.querySelectorAll('.MuiDataGrid-row[data-id]')) {
      const id = r.getAttribute('data-id'), time = first(r.querySelector(sel(timeH.field))), spend = first(r.querySelector(sel(spendH.field)));
      if (/^overall/i.test(time) || id === 'overall-totals') { overall = spend; continue; }
      if (r.getAttribute('aria-level') && r.getAttribute('aria-level') !== '1') continue; // dòng con khi thêm Dimension
      got.set(id, { id, time, spend });
    }
  };
  const sc = grid.querySelector('.MuiDataGrid-virtualScroller');
  const back = sc ? sc.scrollTop : 0;
  if (sc) { sc.scrollTop = 0; await wait(300); }
  grab();
  if (sc) {
    // Bước nửa khung + chờ 350ms: bước lớn hơn làm sót dòng (đã thử: 27/42 dòng)
    for (let last = -1, n = 0; sc.scrollTop !== last && n < 400; n++) { last = sc.scrollTop; sc.scrollTop += Math.max(100, sc.clientHeight / 2); await wait(350); grab(); }
    sc.scrollTop = back;
  }
  // Dự phòng khi data-id không phải mốc giờ: đọc "Oct 12, 00:00 – 01:00", năm lấy theo khoảng ngày (lùi 1 năm nếu tháng lớn hơn tháng cuối khoảng)
  const MON = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
  const ry = range.match(/\b(19|20)\d{2}\b/g), endY = ry ? +ry[ry.length - 1] : new Date().getUTCFullYear();
  const em = range.match(/([A-Za-z]{3})[a-z]*\.?\s+\d{1,2},?\s+(19|20)\d{2}/), endM = em ? MON[em[1].toLowerCase()] : 12;
  const fromText = t => {
    const m = t.match(/([A-Za-z]{3})[a-z]*\.?\s+(\d{1,2}),?\s+(\d{1,2}):(\d{2})/);
    if (!m || !MON[m[1].toLowerCase()]) return t;
    const mo = MON[m[1].toLowerCase()];
    return `${mo > endM ? endY - 1 : endY}-${p2(mo)}-${p2(m[2])} ${p2(m[3])}:00`;
  };
  const rows = [...got.values()].map(x => [/^\d{12,}$/.test(x.id) ? wall(+x.id) : fromText(x.time), x.spend]);
  rows.sort((a, b) => a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0);
  return { ok: true, headers: ['Time (UTC)', spendH.text || 'Spend'], rows, overall, granularity, range, utc, scrapedAt: new Date().toISOString() };
}
