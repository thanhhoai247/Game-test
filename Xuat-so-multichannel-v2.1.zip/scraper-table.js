/* Đọc bảng camp trên trang ITG Marketing Tool (Ant Design table), đã kiểm tra trên trang thật
   https://marketing.itgproduct.com/tiktok/ads-editor: tiêu đề nằm ở bảng riêng (.ant-table-header),
   thân bảng ở .ant-table-body; có cột Campaign Name, Campaign ID, Spend ("8.208 VND"); không chia trang.
   Tự chứa hết vì được tiêm vào trang. Cuộn thân bảng từng đoạn để gom cả dòng ảo hóa (nếu có). */
async function scrapeGenericTable() {
  const clean = s => (s || '').replace(/\s+/g, ' ').trim();
  const lines = s => (s || '').split('\n').map(x => x.trim()).filter(Boolean);
  const wraps = [...document.querySelectorAll('.ant-table-wrapper, .el-table')].filter(w => w.getBoundingClientRect().width > 0);
  const found = [];
  const pickTh = w => [...w.querySelectorAll('thead th')].filter(h => !h.classList.contains('ant-table-cell-scrollbar'));
  for (const wrap of wraps) {
    const ths = pickTh(wrap);
    const headers = ths.map(h => clean(h.innerText));
    found.push(headers);
    if (!headers.some(h => /^(spend|cost)$|chi phí/i.test(h)) || !headers.some(h => /campaign|chiến dịch/i.test(h))) continue;
    const scroller = wrap.querySelector('.ant-table-body') || wrap.querySelector('.ant-table-content');
    const nameIdx = headers.findIndex(h => /^campaign[ _]?name$/i.test(h));
    const idIdx = headers.findIndex(h => /^campaign[ _]?id$/i.test(h));
    const got = new Map();
    const grab = () => {
      for (const tr of wrap.querySelectorAll('tbody tr.ant-table-row, tbody tr.el-table__row')) {
        const tds = [...tr.children];
        if (tds.length < headers.length) continue;
        // Ô tên có nút ẩn "Edit/Duplicate/..." ở dòng sau: chỉ lấy dòng đầu
        const cells = tds.slice(0, headers.length).map((c, i) => i === nameIdx ? (lines(c.innerText)[0] || '') : lines(c.innerText).join(' '));
        const key = (idIdx >= 0 && cells[idIdx]) || cells[nameIdx >= 0 ? nameIdx : 0] + '|' + got.size;
        if (!got.has(key)) got.set(key, cells);
      }
    };
    grab();
    if (scroller && scroller.scrollHeight > scroller.clientHeight + 4) {
      // Bước nửa khung, chờ 350ms, dừng khi không cuộn thêm được (bước lớn dễ sót dòng ở bảng ảo)
      const back = scroller.scrollTop;
      scroller.scrollTop = 0; await new Promise(r => setTimeout(r, 200)); grab();
      for (let last = -1, n = 0; scroller.scrollTop !== last && n < 400; n++) {
        last = scroller.scrollTop;
        scroller.scrollTop += Math.max(100, scroller.clientHeight / 2);
        await new Promise(r => setTimeout(r, 350));
        grab();
      }
      scroller.scrollTop = back;
    }
    const rows = [...got.values()];
    let currencyHint = '';
    const spendIdx = headers.findIndex(h => /^(spend|cost)$/i.test(h));
    for (const r of rows) {
      const m = (r[spendIdx] || '').match(/\b([A-Z]{3})\b|₫|Rp/);
      if (m) { currencyHint = m[1] || (m[0] === '₫' ? 'VND' : 'IDR'); break; }
    }
    // Ô chọn tài khoản TikTok (antd v5: .ant-select-content-value) và nút chọn ngày ("Today: Oct 14, 2026 – Oct 14, 2026")
    const acct = document.querySelector('.ant-select-content-value, .ant-select-selection-item');
    const dateBtn = [...document.querySelectorAll('button, .ant-picker')].map(e => clean(e.innerText)).find(t => /\b(19|20)\d{2}\b/.test(t) && /[–-]/.test(t));
    const pm = document.body.innerText.match(/total\s*(\d[\d.,]*)/i);
    return {
      ok: true, headers, rows, currencyHint, pagerText: pm ? pm[0] : '',
      account: acct ? clean(acct.innerText) : '',
      dateRange: dateBtn || '',
      title: document.title, scrapedAt: new Date().toISOString()
    };
  }
  return { ok: false, error: 'NO_TABLE', found };
}
